package com.example.proyectokotiln

import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import android.widget.LinearLayout


@RunWith(AndroidJUnit4::class)
class test {

    @Test
    fun testMostrarTodosLinearLayouts() {

        ActivityScenario.launch(tienda::class.java).use { scenario ->
            scenario.onActivity { activity ->
                val tienda = activity as tienda
                tienda.mostrarTodosLinearLayouts()
                val layouts = listOf(
                    R.id.layout_camisas,
                    R.id.layout_chaquetas,
                    R.id.layout_pantalones,
                    R.id.layout_tenis
                )
                layouts.forEach { id ->
                    val layout = activity.findViewById<LinearLayout>(id)
                    assertEquals(
                        "El LinearLayout con ID $id no está visible",
                        LinearLayout.VISIBLE,
                        layout.visibility
                    )
                }
            }
        }
    }
}



