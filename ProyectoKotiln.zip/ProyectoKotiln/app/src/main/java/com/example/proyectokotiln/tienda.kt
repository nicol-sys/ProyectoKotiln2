package com.example.proyectokotiln

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.SearchView
import android.widget.LinearLayout
import android.view.View


class tienda : AppCompatActivity() {
    public var isSearchViewClosed = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tienda)

        val username = intent.getStringExtra("USERNAME")
        findViewById<TextView>(R.id.nombreusaer).text = "Bienvenido, $username"

        val searchView = findViewById<SearchView>(R.id.searchView)

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?) = false
            override fun onQueryTextChange(newText: String?): Boolean {
                newText?.let {
                    if (newText.isEmpty() && isSearchViewClosed) mostrarTodosLinearLayouts()
                    else manejarTextoBusqueda(newText)
                }
                return true
            }
        })

        searchView.setOnCloseListener {
            isSearchViewClosed = true
            mostrarTodosLinearLayouts()
            false
        }

        searchView.setOnSearchClickListener { isSearchViewClosed = false }
    }

    public fun mostrarTodosLinearLayouts() {
        val layouts = listOf(
            R.id.layout_camisas,
            R.id.layout_chaquetas,
            R.id.layout_pantalones,
            R.id.layout_tenis
        )
        layouts.forEach { findViewById<LinearLayout>(it).visibility = View.VISIBLE }
    }

    public fun manejarTextoBusqueda(newText: String) {
        val layouts = listOf(
            R.id.layout_camisas,
            R.id.layout_chaquetas,
            R.id.layout_pantalones,
            R.id.layout_tenis
        )

        layouts.forEach { findViewById<LinearLayout>(it).visibility = View.GONE }

        when (newText.toLowerCase()) {
            "camisas" -> findViewById<LinearLayout>(R.id.layout_camisas).visibility = View.VISIBLE
            "chaquetas" -> findViewById<LinearLayout>(R.id.layout_chaquetas).visibility = View.VISIBLE
            "pantalones" -> findViewById<LinearLayout>(R.id.layout_pantalones).visibility = View.VISIBLE
            "tenis" -> findViewById<LinearLayout>(R.id.layout_tenis).visibility = View.VISIBLE
        }
    }
}

